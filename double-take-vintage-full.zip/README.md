# Double Take Vintage

Custom-coded vintage clothing store built with Next.js, React, TailwindCSS, and Stripe Checkout.

## Setup
1. Clone repo
2. Run `npm install`
3. Add `.env.local` file with:
   - STRIPE_SECRET_KEY=sk_test_...
   - STRIPE_WEBHOOK_SECRET=whsec_...
4. Run `npm run dev`

## Deployment
- Push to GitHub
- Connect to Vercel
- Add env vars in Vercel dashboard
- Deploy to free subdomain (e.g. https://doubletakevintage.vercel.app)
