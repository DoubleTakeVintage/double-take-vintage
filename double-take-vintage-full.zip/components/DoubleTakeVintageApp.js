import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ShoppingCart, Plus, Minus } from "lucide-react";

export default function DoubleTakeVintageApp() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [view, setView] = useState("shop"); // shop, cart, admin, policy

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("dtv-products") || "[]");
    if (stored.length === 0) {
      const placeholders = Array.from({ length: 6 }).map((_, i) => ({
        id: `vintage-${i + 1}`,
        name: `Vintage Piece ${i + 1}`,
        price: (30 + i * 10) * 100,
        image: `https://via.placeholder.com/300x400.png?text=Vintage+${i + 1}`,
      }));
      setProducts(placeholders);
      localStorage.setItem("dtv-products", JSON.stringify(placeholders));
    } else {
      setProducts(stored);
    }
  }, []);

  const addToCart = (p) => {
    setCart((prev) => {
      const found = prev.find((it) => it.id === p.id);
      if (found) {
        return prev.map((it) =>
          it.id === p.id ? { ...it, qty: it.qty + 1 } : it
        );
      }
      return [...prev, { ...p, qty: 1 }];
    });
  };

  const updateQty = (id, delta) => {
    setCart((prev) =>
      prev
        .map((it) => (it.id === id ? { ...it, qty: it.qty + delta } : it))
        .filter((it) => it.qty > 0)
    );
  };

  const checkout = async () => {
    const res = await fetch("/api/create-checkout-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: cart }),
    });
    const data = await res.json();
    if (data.id) {
      window.location.href = `https://checkout.stripe.com/pay/${data.id}`;
    }
  };

  const AdminUI = () => {
    const [form, setForm] = useState({ name: "", price: "", image: "" });

    const addProduct = () => {
      const newP = {
        id: `vintage-${Date.now()}`,
        name: form.name,
        price: parseFloat(form.price) * 100,
        image: form.image || `https://via.placeholder.com/300x400.png?text=${form.name}`,
      };
      const updated = [...products, newP];
      setProducts(updated);
      localStorage.setItem("dtv-products", JSON.stringify(updated));
      setForm({ name: "", price: "", image: "" });
    };

    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Admin: Add Product</h2>
        <input
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border p-1 m-1"
        />
        <input
          placeholder="Price (USD)"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          className="border p-1 m-1"
        />
        <input
          placeholder="Image URL"
          value={form.image}
          onChange={(e) => setForm({ ...form, image: e.target.value })}
          className="border p-1 m-1"
        />
        <button onClick={addProduct} className="bg-black text-white p-2 rounded m-1">
          Add Product
        </button>
      </div>
    );
  };

  const PolicyPage = () => (
    <div className="p-4 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-2">Policies</h2>
      <h3 className="text-xl font-semibold">Privacy Policy</h3>
      <p className="mb-4">We respect your privacy. Data is used only for orders.</p>
      <h3 className="text-xl font-semibold">Shipping & Returns</h3>
      <p>All sales are final, but contact us if you have issues with your order.</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="flex justify-between p-4 bg-white shadow">
        <h1
          className="text-2xl font-bold cursor-pointer"
          onClick={() => setView("shop")}
        >
          Double Take Vintage
        </h1>
        <nav className="flex gap-4">
          <button onClick={() => setView("shop")}>Shop</button>
          <button onClick={() => setView("cart")}>
            <ShoppingCart className="inline w-5 h-5" /> ({cart.length})
          </button>
          <button onClick={() => setView("admin")}>Admin</button>
          <button onClick={() => setView("policy")}>Policies</button>
        </nav>
      </header>

      {view === "shop" && (
        <main className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
          {products.map((p) => (
            <motion.div
              key={p.id}
              className="bg-white shadow rounded-xl p-2"
              whileHover={{ scale: 1.05 }}
            >
              <img src={p.image} alt={p.name} className="rounded-xl" />
              <h2 className="font-bold mt-2">{p.name}</h2>
              <p>${(p.price / 100).toFixed(2)}</p>
              <button
                onClick={() => addToCart(p)}
                className="bg-black text-white px-3 py-1 rounded mt-2"
              >
                Add to Cart
              </button>
            </motion.div>
          ))}
        </main>
      )}

      {view === "cart" && (
        <main className="p-4">
          <h2 className="text-xl font-bold mb-2">Your Cart</h2>
          {cart.map((item) => (
            <div key={item.id} className="flex items-center gap-2 mb-2">
              <span>{item.name}</span>
              <button onClick={() => updateQty(item.id, -1)}>
                <Minus className="w-4 h-4" />
              </button>
              <span>{item.qty}</span>
              <button onClick={() => updateQty(item.id, 1)}>
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ))}
          <button
            onClick={checkout}
            className="bg-green-600 text-white px-4 py-2 rounded mt-2"
          >
            Checkout
          </button>
        </main>
      )}

      {view === "admin" && <AdminUI />}
      {view === "policy" && <PolicyPage />}
    </div>
  );
}