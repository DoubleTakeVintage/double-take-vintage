import DoubleTakeVintageApp from "../components/DoubleTakeVintageApp";

export default function Home() {
  return <DoubleTakeVintageApp />;
}
